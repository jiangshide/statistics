需求:编写SDK，限制Office软件只能在JINGPAD上运行
API调用:主要用于校验软件的:
1.直接调用验证接口：包括model的验证
Security.getInstance().isValidate();//true:通过,false:不通过

